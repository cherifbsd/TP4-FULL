import React from "react";
function App2() {
    return (
      <UserProvider>
        <UserProfile />
        <Notifications />
        <NotificationCounter />
      </UserProvider>
    );
  }
  
  export default App2;